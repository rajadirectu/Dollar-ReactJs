import React,{Component} from 'react';

class Home extends Component { 
    render() {
        return (
            <div className='home'>
                <h1>Welcome to License Application</h1>
            </div>
        );
    }
}

export default Home;


