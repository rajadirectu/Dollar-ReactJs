import React, {Component} from 'react';

class BusinessLicense extends Component { 
    render(){
        return (
            <div className='businessLicense'>
                <h1>This is BusinessLicense</h1>
            </div>
        );
    }
}

export default BusinessLicense;